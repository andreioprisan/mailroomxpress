# ************************************************************
# Sequel Pro SQL dump
# Version 3408
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.9)
# Database: mrxp
# Generation Time: 2012-04-27 17:31:27 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table 3NMailRoomAccess
# ------------------------------------------------------------

DROP TABLE IF EXISTS `3NMailRoomAccess`;

CREATE TABLE `3NMailRoomAccess` (
  `Username` varchar(20) NOT NULL,
  `AccessLevel` varchar(20) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `IsActive` varchar(5) NOT NULL DEFAULT 'Yes',
  `IsAdmin` varchar(5) NOT NULL DEFAULT 'Yes',
  `LastMod` datetime NOT NULL,
  PRIMARY KEY (`Username`),
  KEY `Status` (`Status`),
  KEY `IsActive` (`IsActive`),
  KEY `IsAdmin` (`IsAdmin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `3NMailRoomAccess` WRITE;
/*!40000 ALTER TABLE `3NMailRoomAccess` DISABLE KEYS */;

INSERT INTO `3NMailRoomAccess` (`Username`, `AccessLevel`, `FirstName`, `LastName`, `Password`, `Email`, `Status`, `IsActive`, `IsAdmin`, `LastMod`)
VALUES
	('ao631','staff','Andrei','Oprisan','123','andrei.oprisan@nyu.edu','Active','Yes','Yes','0000-00-00 00:00:00'),
	('root','all','Root','User','root','root@root.com','Active','Yes','Yes','2009-10-06 09:50:01');

/*!40000 ALTER TABLE `3NMailRoomAccess` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table 3NMailRoomAnnouncements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `3NMailRoomAnnouncements`;

CREATE TABLE `3NMailRoomAnnouncements` (
  `LastModificationTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Recipient` varchar(25) NOT NULL DEFAULT '',
  `MessageContent` longtext NOT NULL,
  PRIMARY KEY (`Recipient`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `3NMailRoomAnnouncements` WRITE;
/*!40000 ALTER TABLE `3NMailRoomAnnouncements` DISABLE KEYS */;

INSERT INTO `3NMailRoomAnnouncements` (`LastModificationTime`, `Recipient`, `MessageContent`)
VALUES
	('0000-00-00 00:00:00','GlobalMessage','Use the workpad if you have any unfinished work! That way, the person after you knows where you left off.'),
	('2009-10-07 00:00:00','ao631','Please don\'t forget to write BOTH the resident\'s name and their BOX number on each package.');

/*!40000 ALTER TABLE `3NMailRoomAnnouncements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table 3NMailRoomBoxesCombinations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `3NMailRoomBoxesCombinations`;

CREATE TABLE `3NMailRoomBoxesCombinations` (
  `lastname` varchar(30) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `box` varchar(20) NOT NULL,
  `tower` varchar(2) NOT NULL,
  `room` varchar(5) NOT NULL,
  `side` varchar(2) NOT NULL,
  `combo` varchar(10) NOT NULL,
  KEY `lastname` (`lastname`),
  KEY `firstname` (`firstname`),
  KEY `box` (`box`),
  KEY `tower` (`tower`),
  KEY `room` (`room`),
  KEY `side` (`side`),
  KEY `combo` (`combo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `3NMailRoomBoxesCombinations` WRITE;
/*!40000 ALTER TABLE `3NMailRoomBoxesCombinations` DISABLE KEYS */;

INSERT INTO `3NMailRoomBoxesCombinations` (`lastname`, `firstname`, `box`, `tower`, `room`, `side`, `combo`)
VALUES
	('Smith','John','1000','E','123A','1','1-2-3');

/*!40000 ALTER TABLE `3NMailRoomBoxesCombinations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table 3NMailRoomPackages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `3NMailRoomPackages`;

CREATE TABLE `3NMailRoomPackages` (
  `id` smallint(10) NOT NULL AUTO_INCREMENT,
  `netid` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `carrier` varchar(20) NOT NULL,
  `color` varchar(15) NOT NULL,
  `count` varchar(2) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `location` varchar(30) NOT NULL,
  `shape` varchar(50) NOT NULL,
  `size` varchar(50) NOT NULL,
  `isperishable` varchar(10) DEFAULT 'No',
  `recordedby` varchar(10) NOT NULL,
  `recordedon` datetime NOT NULL,
  `signedfor` varchar(3) NOT NULL,
  `signedunderuser` varchar(10) NOT NULL,
  `signeddate` datetime NOT NULL,
  `deleted` varchar(3) NOT NULL DEFAULT 'No',
  `deletedby` varchar(10) NOT NULL,
  `deletedon` datetime NOT NULL,
  `emailed` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `signedpage` varchar(4) DEFAULT NULL,
  `signedline` varchar(4) DEFAULT NULL,
  `signedswipe` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`id`),
  KEY `netid` (`netid`),
  KEY `name` (`name`),
  KEY `recordedby` (`recordedby`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `3NMailRoomPackages` WRITE;
/*!40000 ALTER TABLE `3NMailRoomPackages` DISABLE KEYS */;

INSERT INTO `3NMailRoomPackages` (`id`, `netid`, `name`, `carrier`, `color`, `count`, `description`, `location`, `shape`, `size`, `isperishable`, `recordedby`, `recordedon`, `signedfor`, `signedunderuser`, `signeddate`, `deleted`, `deletedby`, `deletedon`, `emailed`, `signedpage`, `signedline`, `signedswipe`)
VALUES
	(1,'ao631','Andrei Oprisan','USPS','Blue','1','','','Box','Small','','ao631','2009-10-28 21:29:14','Yes','ao631','2009-10-28 21:29:24','No','','0000-00-00 00:00:00','Yes','12','4','No');

/*!40000 ALTER TABLE `3NMailRoomPackages` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table 3NMailRoomUsers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `3NMailRoomUsers`;

CREATE TABLE `3NMailRoomUsers` (
  `lastname` varchar(30) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `nnumber` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `birthday` varchar(30) NOT NULL,
  `age` varchar(3) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `tower` varchar(1) NOT NULL,
  `room` varchar(10) NOT NULL,
  `side` varchar(2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `modby` varchar(20) NOT NULL,
  `lastmod` datetime NOT NULL,
  KEY `nnumber` (`nnumber`),
  KEY `email` (`email`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `room` (`room`),
  KEY `side` (`side`),
  KEY `status` (`status`),
  KEY `birthday` (`birthday`),
  KEY `tower` (`tower`),
  KEY `modby` (`modby`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `3NMailRoomUsers` WRITE;
/*!40000 ALTER TABLE `3NMailRoomUsers` DISABLE KEYS */;

INSERT INTO `3NMailRoomUsers` (`lastname`, `firstname`, `nnumber`, `email`, `birthday`, `age`, `gender`, `tower`, `room`, `side`, `status`, `modby`, `lastmod`)
VALUES
	('Oprisan','Andrei','12345678','andrei.oprisan@mac.com','1/2/80','18','M','E','123A','1','Current Freshman','','0000-00-00 00:00:00');

/*!40000 ALTER TABLE `3NMailRoomUsers` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table 3NMailRoomWorkpads
# ------------------------------------------------------------

DROP TABLE IF EXISTS `3NMailRoomWorkpads`;

CREATE TABLE `3NMailRoomWorkpads` (
  `Username` varchar(25) NOT NULL DEFAULT '',
  `Content` longtext NOT NULL,
  `LastModificationTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `Username` (`Username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `3NMailRoomWorkpads` WRITE;
/*!40000 ALTER TABLE `3NMailRoomWorkpads` DISABLE KEYS */;

INSERT INTO `3NMailRoomWorkpads` (`Username`, `Content`, `LastModificationTime`)
VALUES
	('ao631','yeyeaaaah','2009-10-31 11:19:08');

/*!40000 ALTER TABLE `3NMailRoomWorkpads` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ci_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



# Dump of table login_attempts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `login_attempts`;

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



# Dump of table permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `permissions`;

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `data` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



# Dump of table roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(30) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;

INSERT INTO `roles` (`id`, `parent_id`, `name`)
VALUES
	(1,0,X'55736572'),
	(2,0,X'41646D696E');

/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user_autologin
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_autologin`;

CREATE TABLE `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



# Dump of table user_profile
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_profile`;

CREATE TABLE `user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;

INSERT INTO `user_profile` (`id`, `user_id`, `country`, `website`)
VALUES
	(1,1,NULL,NULL);

/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user_temp
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_temp`;

CREATE TABLE `user_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(34) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `activation_key` varchar(50) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '1',
  `username` varchar(25) COLLATE utf8_bin NOT NULL,
  `password` varchar(34) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `newpass` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `newpass_key` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `newpass_time` datetime DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `role_id`, `username`, `password`, `email`, `banned`, `ban_reason`, `newpass`, `newpass_key`, `newpass_time`, `last_ip`, `last_login`, `created`, `modified`)
VALUES
	(1,2,X'61646D696E',X'2431246937352E446F342E24524F50525A6A5A7A44782F4A6A71655674614A4C572E',X'61646D696E406C6F63616C686F73742E636F6D',0,NULL,NULL,NULL,NULL,X'3132372E302E302E31','2008-11-30 04:56:38','2008-11-30 04:56:32','2008-11-30 04:56:38'),
	(2,1,X'75736572',X'243124624F2E2E4952342E2443786A4A426A4B4A355157322F4261594B445337662E',X'75736572406C6F63616C686F73742E636F6D',0,NULL,NULL,NULL,NULL,X'3132372E302E302E31','2008-12-01 14:04:14','2008-12-01 14:01:53','2008-12-01 14:04:14');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
